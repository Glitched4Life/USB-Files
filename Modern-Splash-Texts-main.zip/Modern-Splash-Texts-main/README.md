Modern Splash Texts was added so everyone using 1.8.9 or newer can use all of the
splash texts from that was released from 1.9.0 all the way up to 1.19.3 Pre Release 1's Release/Snapshot!
this resource pack was also a contribution to technoblade. farewell to the king. 1999-2022